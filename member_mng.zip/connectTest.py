import psycopg2

conn = psycopg2.connect(
    host="localhost",
    port=5432,
    database="testdb",
    user="myuser",
    password="1234"
)

cursor = conn.cursor()
cursor.execute("SELECT current_date")

for row in cursor.fetchall():
    print(row)

cursor.close()
conn.close()