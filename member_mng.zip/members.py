import tkinter as tk
from tkinter import ttk, messagebox
from database import list_members
from member_detail import MemberDetail

class Members(ttk.Frame):
    def __init__(self, root, on_logout):
        super().__init__(root,padding=16)
        self.pack(fill='both',expand=True)
        header=ttk.Frame(self); header.pack(fill='x',pady=(0,15))
        ttk.Label(header,text='회원관리 | 관리자',font=('맑은 고딕',20,'bold')).pack(side='left')
        ttk.Button(header,text='로그아웃',command=on_logout).pack(side='right')
        bar=ttk.Frame(self); bar.pack(fill='x',pady=(0,12))
        ttk.Label(bar,text='회원명').pack(side='left')
        self.name=ttk.Entry(bar,width=15); self.name.pack(side='left',padx=6)
        ttk.Label(bar,text='휴대폰번호').pack(side='left')
        self.phone=ttk.Entry(bar,width=18); self.phone.pack(side='left',padx=6)
        ttk.Button(bar,text='검색',command=self.refresh).pack(side='left',padx=4)
        ttk.Button(bar,text='전체 조회',command=self.reset).pack(side='left',padx=4)
        ttk.Button(bar,text='신규 회원 등록',command=lambda:MemberDetail(root,self.refresh)).pack(side='right')
        area=ttk.Frame(self); area.pack(fill='both',expand=True)
        cols=('member_no','member_name','member_id','phone','address','email')
        self.tree=ttk.Treeview(area,columns=cols,show='headings',selectmode='browse')
        for c,h,w in zip(cols,('회원번호','회원명','회원ID','휴대폰번호','주소','이메일'),(75,100,120,145,220,200)):
            self.tree.heading(c,text=h); self.tree.column(c,width=w,anchor='w')
        ys=ttk.Scrollbar(area,orient='vertical',command=self.tree.yview)
        xs=ttk.Scrollbar(area,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        area.rowconfigure(0,weight=1); area.columnconfigure(0,weight=1)
        self.tree.grid(row=0,column=0,sticky='nsew'); ys.grid(row=0,column=1,sticky='ns'); xs.grid(row=1,column=0,sticky='ew')
        self.status=ttk.Label(self,text=''); self.status.pack(anchor='w',pady=8)
        def detail(event):
            item=self.tree.identify_row(event.y)
            if item and self.tree.identify_region(event.x,event.y)=='cell':
                MemberDetail(root,self.refresh,int(item))
        self.tree.bind('<ButtonRelease-1>',detail)
        self.name.bind('<Return>',lambda e:self.refresh()); self.phone.bind('<Return>',lambda e:self.refresh())
        self.refresh()
    def reset(self):
        self.name.delete(0,tk.END); self.phone.delete(0,tk.END); self.refresh()
    def refresh(self):
        try:
            rows=list_members(self.name.get().strip(),self.phone.get().strip())
        except Exception as e:
            messagebox.showerror('조회 실패',str(e),parent=self); return
        for item in self.tree.get_children(): self.tree.delete(item)
        for row in rows:
            self.tree.insert('', 'end', iid=str(row['member_no']),values=tuple(row[c] if row[c] is not None else '' for c in self.tree['columns']))
        self.status.configure(text=f'조회 결과: {len(rows)}명 | 회원을 클릭하면 상세정보가 열립니다.')
