-- pgAdmin에서 postgres 데이터베이스에 postgres 계정으로 연결한 후 실행
CREATE DATABASE memberdb OWNER myuser;
