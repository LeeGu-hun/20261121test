import tkinter as tk
from tkinter import ttk, messagebox
from psycopg2.errors import UniqueViolation
from database import get_member, add_member, update_member, delete_member

class MemberDetail(tk.Toplevel):
    def __init__(self, parent, refresh, no=None):
        super().__init__(parent)
        self.title('회원 등록' if no is None else '회원 상세정보')
        self.geometry('540x470')
        self.transient(parent)
        self.resizable(False, False)
        try:
            row = get_member(no) if no is not None else {}
            if row is None:
                raise ValueError('회원이 존재하지 않습니다.')
        except Exception as e:
            messagebox.showerror('오류', str(e), parent=self)
            self.destroy()
            return
        self.grab_set()
        frame = ttk.Frame(self, padding=22)
        frame.pack(fill='both', expand=True)
        frame.columnconfigure(1, weight=1)
        fields = [('member_no','회원번호',None),('member_name','회원명',50),('member_id','회원ID',50),('password','비밀번호' if no is None else '새 비밀번호',None),('phone','휴대폰번호',20),('address','주소',300),('email','이메일',100)]
        self.entries = {}
        for i,(key,label,limit) in enumerate(fields):
            ttk.Label(frame,text=label).grid(row=i,column=0,sticky='w',pady=7,padx=(0,14))
            entry=ttk.Entry(frame,show='*' if key=='password' else '')
            entry.grid(row=i,column=1,sticky='ew',pady=7)
            entry.insert(0, str(row.get(key) or ('자동 생성' if key=='member_no' else '')))
            if key=='member_no' or (key=='member_id' and no is not None):
                entry.configure(state='readonly')
            self.entries[key]=entry
        ttk.Label(frame,text='비밀번호 미입력 시 기존 비밀번호 유지' if no is not None else '회원명, 회원ID, 비밀번호는 필수입니다.').grid(row=7,column=0,columnspan=2,pady=8)
        def save():
            v={k:e.get().strip() if k!='password' else e.get() for k,e in self.entries.items()}
            if not v['member_name'] or not v['member_id'] or (no is None and not v['password']):
                messagebox.showwarning('입력 확인','필수 항목을 입력하세요.',parent=self); return
            for key,label,limit in fields:
                if limit and len(v[key])>limit:
                    messagebox.showwarning('입력 확인',f'{label}은 {limit}자 이내로 입력하세요.',parent=self); return
            if len(v['password'].encode('utf-8'))>72:
                messagebox.showwarning('입력 확인','비밀번호는 UTF-8 기준 72바이트 이내로 입력하세요.',parent=self); return
            try:
                if no is None:
                    add_member(v['member_name'],v['member_id'],v['password'],v['phone'],v['address'],v['email'])
                else:
                    update_member(no,v['member_name'],v['password'],v['phone'],v['address'],v['email'])
            except UniqueViolation:
                messagebox.showwarning('중복 ID','이미 사용 중인 회원ID입니다.',parent=self); return
            except Exception as e:
                messagebox.showerror('저장 실패',str(e),parent=self); return
            messagebox.showinfo('완료','저장되었습니다.',parent=self)
            self.destroy(); refresh()
        def remove():
            if not messagebox.askyesno('삭제 확인','정말 삭제하시겠습니까?',parent=self): return
            try:
                delete_member(no)
            except Exception as e:
                messagebox.showerror('삭제 실패',str(e),parent=self); return
            self.destroy(); refresh()
        buttons=ttk.Frame(frame); buttons.grid(row=8,column=0,columnspan=2,pady=14)
        ttk.Button(buttons,text='등록' if no is None else '수정',command=save).pack(side='left',padx=5)
        if no is not None:
            ttk.Button(buttons,text='삭제',command=remove,state='disabled' if row['member_id']=='admin' else 'normal').pack(side='left',padx=5)
        ttk.Button(buttons,text='닫기',command=self.destroy).pack(side='left',padx=5)
