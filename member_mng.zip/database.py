import os
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor
import bcrypt

@contextmanager
def db():
    conn = psycopg2.connect(host='10.100.203.62', port=5432, dbname='testdb', user='myuser', password=os.getenv('MEMBER_DB_PASSWORD', '1234'), connect_timeout=5)
    try:
        with conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                yield cur
    finally:
        conn.close()

def hash_password(value):
    return bcrypt.hashpw(value.encode('utf-8'), bcrypt.gensalt()).decode('ascii')

def initialize():
    with db() as cur:
        cur.execute('''CREATE TABLE IF NOT EXISTS members (
            member_no SERIAL PRIMARY KEY,
            member_name VARCHAR(50) NOT NULL,
            member_id VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(20), address VARCHAR(300), email VARCHAR(100)
        )''')
        cur.execute('SELECT member_no FROM members WHERE member_id=%s', ('admin',))
        if not cur.fetchone():
            cur.execute('INSERT INTO members (member_name, member_id, password) VALUES (%s,%s,%s) ON CONFLICT (member_id) DO NOTHING', ('관리자','admin',hash_password('1234')))

def authenticate(member_id, password):
    if member_id != 'admin' or len(password.encode('utf-8')) > 72:
        return False
    with db() as cur:
        cur.execute('SELECT password FROM members WHERE member_id=%s', (member_id,))
        row = cur.fetchone()
    return bool(row and bcrypt.checkpw(password.encode('utf-8'), row['password'].encode('ascii')))

FIELDS = 'member_no, member_name, member_id, phone, address, email'

def list_members(name='', phone=''):
    with db() as cur:
        cur.execute(f'SELECT {FIELDS} FROM members WHERE member_name ILIKE %s AND COALESCE(phone, \'\') ILIKE %s ORDER BY member_no', ('%'+name+'%', '%'+phone+'%'))
        return cur.fetchall()

def get_member(no):
    with db() as cur:
        cur.execute(f'SELECT {FIELDS} FROM members WHERE member_no=%s', (no,))
        return cur.fetchone()

def add_member(name, member_id, password, phone, address, email):
    with db() as cur:
        cur.execute('INSERT INTO members (member_name,member_id,password,phone,address,email) VALUES (%s,%s,%s,%s,%s,%s)', (name, member_id, hash_password(password), phone, address, email))

def update_member(no, name, password, phone, address, email):
    with db() as cur:
        if password:
            cur.execute('UPDATE members SET member_name=%s,password=%s,phone=%s,address=%s,email=%s WHERE member_no=%s', (name,hash_password(password),phone,address,email,no))
        else:
            cur.execute('UPDATE members SET member_name=%s,phone=%s,address=%s,email=%s WHERE member_no=%s', (name,phone,address,email,no))
        if cur.rowcount != 1:
            raise ValueError('회원이 존재하지 않습니다.')

def delete_member(no):
    with db() as cur:
        cur.execute("DELETE FROM members WHERE member_no=%s AND member_id <> 'admin'", (no,))
        if cur.rowcount != 1:
            raise ValueError('관리자 계정은 삭제할 수 없거나 회원이 존재하지 않습니다.')
