1. PostgreSQL 서비스가 실행 중인지 확인합니다.
2. pgAdmin에서 postgres 계정으로 postgres DB에 연결하고 init_db.sql의 CREATE DATABASE 문을 실행합니다. 이미 memberdb가 있고 myuser가 소유자이면 생략합니다.
3. PyCharm에서 이 폴더를 열고 Python 3.12 가상환경을 선택합니다.
4. 터미널: python -m pip install -r requirements.txt
5. 터미널: python main.py
6. 로그인 admin / 1234. 테이블과 관리자는 최초 실행 시 자동 생성됩니다. 기존 관리자 비밀번호는 초기화하지 않습니다.
관리자만 로그인할 수 있습니다. 관리자 삭제는 차단됩니다. 두 검색 조건은 AND로 결합됩니다.
실습용 초기 비밀번호입니다. 실제 사용 시 관리자 비밀번호를 상세 화면에서 변경하고 DB 비밀번호를 변경한 후 MEMBER_DB_PASSWORD 환경변수에 설정하세요.
