import tkinter as tk
from tkinter import ttk, messagebox
from database import authenticate

class Login(ttk.Frame):
    def __init__(self, root, on_login):
        super().__init__(root, padding=30)
        self.pack(expand=True)
        ttk.Label(self, text='회원관리 시스템', font=('맑은 고딕', 22, 'bold')).pack(pady=(0,24))
        ttk.Label(self, text='관리자 ID').pack(anchor='w')
        self.uid = ttk.Entry(self, width=30)
        self.uid.pack(pady=(4,12))
        ttk.Label(self, text='비밀번호').pack(anchor='w')
        self.pw = ttk.Entry(self, width=30, show='*')
        self.pw.pack(pady=(4,16))
        def submit(event=None):
            try:
                ok = authenticate(self.uid.get().strip(), self.pw.get())
            except Exception:
                messagebox.showerror('오류','DB 연결 또는 인증 처리에 실패했습니다.', parent=root)
                return
            if ok:
                on_login()
            else:
                messagebox.showwarning('로그인 실패','관리자 ID 또는 비밀번호를 확인하세요.', parent=root)
                self.pw.delete(0, tk.END)
        ttk.Button(self, text='로그인', command=submit).pack(fill='x')
        self.uid.bind('<Return>', submit)
        self.pw.bind('<Return>', submit)
        self.uid.focus_set()
