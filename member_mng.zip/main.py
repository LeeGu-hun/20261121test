import tkinter as tk
from tkinter import ttk, messagebox
from database import initialize
from login import Login
from members import Members

def main():
    root=tk.Tk(); root.title('회원관리 시스템')
    root.option_add('*Font',('맑은 고딕',11))
    ttk.Style(root).configure('Treeview',rowheight=31)
    root.withdraw()
    try:
        initialize()
    except Exception as e:
        messagebox.showerror('초기화 실패',f'PostgreSQL 설정과 memberdb 생성 여부를 확인하세요.\n{e}',parent=root)
        root.destroy(); return
    def clear():
        for child in root.winfo_children(): child.destroy()
    def login():
        clear(); root.geometry('440x350'); root.minsize(440,350); Login(root,show_members)
    def show_members():
        clear(); root.geometry('1050x600'); root.minsize(850,450); Members(root,login)
    login(); root.deiconify(); root.mainloop()

if __name__=='__main__': main()
